set(0, 'DefaultFigurePosition', [25 550 500 400]);
set(0, 'DefaultAxesFontSize', 8);
set(0, 'DefaultAxesFontName', 'Helvetica');
set(0, 'DefaultAxesFontWeight','bold');
set(0,'defaultsurfaceedgecolor','none');
set(0,'defaultaxestickdir','out');
set(0,'defaultaxesfontweight','bold');
% Set miscellaneous properties.
set(0,'DefaultLineLineWidth',1)
set(0,'DefaultPatchLineWidth',1)
set(0,'DefaultTextFontSize',10);
set(0,'DefaultUicontrolFontSize',8);
corder = [0,0,1;1,0,0;0,1,0;0,0,0;0.75,0,0.75;0,0.75,0.75;0.75,0.75,0];
set(0,'defaultaxescolororder',corder)
clear corder 


% -------------------------------------
% Indicate startup is done with a happy greeting.

% Definitions:
%   Morning    5.00am   - 11.59am
%   Afternoon 12.00noon -  5.00pm
%   Evening    5.01pm   - 10.00pm
%   Night     10.01pm   -  4.59am

realname = '';
if isunix %strcmpi('linux',char(java.lang.System.getProperty('os.name')))
	[exitflag output]=unix('which finger>/dev/null 2>&1 && finger -l $USER|grep Name:|awk ''{print $4}''');
	if exitflag==0
		realname = [', ' output(1:end-1)];
	end
end

h = hour(now);
if h>=5 && h<12
	fprintf('Good morning%s.\n',realname);
elseif h>=12 && h<17
	fprintf('Good afternoon%s.\n',realname);
elseif h>=17 && h<22
	fprintf('Good evening%s.\n',realname);
elseif h>=22 && h<5
	fprintf('Good night%s.\n',realname);
else
	% cant be here
end

clear exitflag h output realname;

