params.displayType='all'
family=U.AH62.fits.all;
buildfits;

params.displayType='arbitrary'
params.arbTimes={'0';'.72'}
family=U.AH62.fits.prePole;
buildfits;

params.displayType='poleToDecision'
family=U.AH62.fits.decision;
buildfits;



