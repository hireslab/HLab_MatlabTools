set(0, 'DefaultFigurePosition', [25 550 500 400]);
set(0, 'DefaultAxesFontSize', 12);
set(0, 'DefaultAxesFontName', 'Helvetica');
set(0, 'DefaultAxesFontWeight','bold');
set(0,'defaultsurfaceedgecolor','none');
set(0,'defaultaxestickdir','out');
set(0,'defaultaxesfontweight','bold');
% Set miscellaneous properties.
set(0,'DefaultLineLineWidth',2);
set(0,'DefaultLineMarkerSize',12);
set(0,'DefaultPatchLineWidth',1);
set(0,'DefaultTextFontSize',18);
set(0,'DefaultTextFontWeight','bold');
set(0,'DefaultUicontrolFontSize',8);
corder = [0,0,1;1,0,0;0,1,0;0,0,0;0.75,0,0.75;0,0.75,0.75;0.75,0.75,0];
set(0,'defaultaxescolororder',corder)
clear corder 
